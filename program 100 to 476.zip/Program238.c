#include<stdio.h>
#include<stdlib.h>

#pragma pack(1)     // 7th January
struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

typedef struct node NODE;
typedef struct node * PNODE;
typedef struct node ** PPNODE;

int main()
{
    PNODE Head = NULL;
    PNODE Tail = NULL;

    return 0;
}